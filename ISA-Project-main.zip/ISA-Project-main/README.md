# ISA-Project
The ISA Proj file and all files in Cryptography folder,uses the pycryptodome package that needs to be installed.
Also, for the setup and interface, tkinter module is required.
